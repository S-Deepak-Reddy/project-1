# Supplier Selection and Cold Start System

A machine learning-powered web application for supplier selection and compliance prediction in supply chain management. This system helps evaluate new suppliers (cold-start) and predict compliance rates using Random Forest classification.

## Project Overview

**Project Name:** Supplier Selection and Cold Start Supplier Selection in Supply Chain Management

### Key Features
- **93.36% Accuracy** Random Forest model for compliance prediction
- **Cold-Start Capability** - Works with new suppliers without historical data
- **Interactive Web Interface** - User-friendly Streamlit dashboard
- **Real-time Predictions** - Single supplier evaluation
- **Batch Processing** - Evaluate multiple suppliers at once
- **Performance Metrics** - View model comparisons and statistics

### Model Performance
- **Best Model:** Random Forest Classifier
- **Accuracy:** 93.36%
- **ROC-AUC:** 0.9744
- **Precision:** 0.9744
- **Recall:** 0.8906

## Project Structure

```
deepak/
├── app.py                          # Main Streamlit application
├── train_and_save_model.py        # Model training script
├── export_model_cell.txt           # Colab export code
├── requirements.txt                # Python dependencies
├── README.md                       # This file
├── Procurement KPI Analysis Dataset.csv  # Training data
├── Untitled41 (1).ipynb           # Original analysis notebook
│
└── Model Artifacts (to be generated):
    ├── model.pkl                   # Trained Random Forest model
    ├── scaler.pkl                  # StandardScaler for preprocessing
    ├── feature_columns.pkl         # Feature column names
    └── label_encoders.pkl          # Label encoders for categorical variables
```

## Setup Instructions

### Step 1: Export Model from Google Colab

Since your model was trained in Google Colab, you need to export the model artifacts:

1. Open your notebook: `Untitled41 (1).ipynb` in Google Colab
2. Add a new cell at the end with the following code:

```python
import pickle
from google.colab import files

# Save the Random Forest model (best performing)
with open('model.pkl', 'wb') as f:
    pickle.dump(models["Random Forest"], f)

# Save the scaler
with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

# Save feature columns
with open('feature_columns.pkl', 'wb') as f:
    pickle.dump(X_cold.columns.tolist(), f)

# Save label encoders
label_encoders_dict = {'target_encoder': le}
with open('label_encoders.pkl', 'wb') as f:
    pickle.dump(label_encoders_dict, f)

# Download files
files.download('model.pkl')
files.download('scaler.pkl')
files.download('feature_columns.pkl')
files.download('label_encoders.pkl')
```

3. Run the cell and download all 4 `.pkl` files
4. Place them in your project directory (`C:\Users\Admin\deepak\`)

### Step 2: Prepare for Deployment

**Option A: Test Locally First**

```bash
# Install dependencies
pip install -r requirements.txt

# Run the app locally
streamlit run app.py
```

**Option B: Deploy Directly to Streamlit Cloud**

Continue to Step 3 below.

### Step 3: Deploy to Streamlit Cloud

1. **Create a GitHub Repository**
   ```bash
   git init
   git add app.py requirements.txt README.md model.pkl scaler.pkl feature_columns.pkl label_encoders.pkl "Procurement KPI Analysis Dataset.csv"
   git commit -m "Initial commit: Supplier selection ML app"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/supplier-selection-app.git
   git push -u origin main
   ```

2. **Deploy on Streamlit Cloud**
   - Go to [share.streamlit.io](https://share.streamlit.io/)
   - Click "New app"
   - Select your GitHub repository
   - Set main file path: `app.py`
   - Click "Deploy"

3. **Wait for Deployment**
   - Streamlit Cloud will install dependencies from `requirements.txt`
   - The app will be live at: `https://share.streamlit.io/YOUR_USERNAME/supplier-selection-app`

## Usage Guide

### Single Prediction Mode
1. Select "Single Prediction" from the sidebar
2. Enter supplier information:
   - Order date and delivery date
   - Item category and order status
   - Quantity, pricing, and defect information
3. Click "Predict Compliance"
4. View prediction results, confidence scores, and recommendations

### Batch Prediction Mode
1. Select "Batch Prediction" from the sidebar
2. Upload a CSV file with the required columns
3. Click "Process Batch"
4. Download results with predictions

### Model Performance Mode
1. Select "Model Performance" from the sidebar
2. View comparison charts for all trained models
3. Review detailed metrics for the best model

## Required CSV Format for Batch Processing

Your CSV should include these columns:
- `Quantity`: Number of units ordered
- `Unit_Price`: Price per unit
- `Negotiated_Price`: Final negotiated price
- `Defective_Units`: Number of defective items
- `Order_Date`: Order placement date (YYYY-MM-DD)
- `Delivery_Date`: Expected/actual delivery date (YYYY-MM-DD)
- `Item_Category`: Product category
- `Order_Status`: Current order status

## Technical Details

### Machine Learning Pipeline
1. **Data Preprocessing**
   - Missing value imputation
   - Date feature extraction
   - Label encoding for categorical variables
   - Standard scaling for numerical features

2. **Feature Engineering**
   - Delivery delay calculation
   - Defective ratio
   - Price difference metrics
   - Temporal features (year, month, day)
   - Cold-start features (global averages)

3. **Model Training**
   - SMOTE for class imbalance handling
   - Train-test split (80-20)
   - Random Forest with 200 estimators
   - Cross-validation for hyperparameter tuning

4. **Evaluation Metrics**
   - Accuracy, Precision, Recall, F1-Score
   - ROC-AUC curve
   - Confusion matrix

### Models Compared
- Logistic Regression
- Random Forest (Selected)
- Gradient Boosting
- SVM
- K-Nearest Neighbors
- XGBoost

## Dependencies

See `requirements.txt` for full list:
- streamlit
- pandas
- numpy
- scikit-learn
- imbalanced-learn
- xgboost
- plotly

## Troubleshooting

### Model files not found
- Ensure all `.pkl` files are in the project root directory
- Re-run the export cell in your Colab notebook

### Import errors
- Make sure all dependencies are installed: `pip install -r requirements.txt`
- Check Python version compatibility (3.8+)

### Streamlit Cloud deployment fails
- Verify `requirements.txt` has all dependencies
- Check that all model files are committed to GitHub
- Ensure file sizes are within GitHub limits (100MB per file)

## Future Enhancements

- [ ] Add supplier performance tracking over time
- [ ] Implement A/B testing for model comparison
- [ ] Add more visualization options
- [ ] Include supplier recommendation system
- [ ] API endpoint for integration with ERP systems
- [ ] Historical trend analysis

## Contact & Support

For issues or questions about this project, please refer to your project documentation or contact your development team.

## License

This project is for educational and research purposes.

---

**Built with:**
- Python 3.11
- Streamlit
- Scikit-learn
- Random Forest ML
- Google Colab for training

**Project Status:** Ready for Deployment
