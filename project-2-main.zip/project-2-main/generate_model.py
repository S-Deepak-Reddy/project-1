"""
Generate model files from your dataset for local deployment
"""

import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import LabelEncoder, StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from collections import Counter

print("="*70)
print("GENERATING MODEL FOR LOCAL STREAMLIT APP")
print("="*70)

# Load data
print("\n[1/6] Loading data...")
df = pd.read_csv("Procurement KPI Analysis Dataset.csv")
print(f"✓ Data loaded: {df.shape}")

# Handle missing values
print("\n[2/6] Preprocessing data...")
df['Delivery_Date'] = pd.to_datetime(df['Delivery_Date'], errors='coerce')
df['Order_Date'] = pd.to_datetime(df['Order_Date'], errors='coerce')

mean_delay = (df['Delivery_Date'] - df['Order_Date']).dt.days.mean()
df['Delivery_Date'] = df['Delivery_Date'].fillna(df['Order_Date'] + pd.to_timedelta(mean_delay, unit='d'))
df['Defective_Units'] = df['Defective_Units'].fillna(df['Defective_Units'].median())

# Feature Engineering
df['Order_Year'] = df['Order_Date'].dt.year
df['Order_Month'] = df['Order_Date'].dt.month
df['Order_Day'] = df['Order_Date'].dt.day
df['Delivery_Year'] = df['Delivery_Date'].dt.year
df['Delivery_Month'] = df['Delivery_Date'].dt.month
df['Delivery_Day'] = df['Delivery_Date'].dt.day
df['Delivery_Delay'] = (df['Delivery_Date'] - df['Order_Date']).dt.days

df = df.drop(columns=['Order_Date', 'Delivery_Date', 'PO_ID'])

# Drop cold-start unavailable features BEFORE encoding
# These fields are not available for new suppliers
df = df.drop(columns=['Defective_Units', 'Order_Status'], errors='ignore')
print(f"✓ Dropped cold-start unavailable features (Defective_Units, Order_Status)")

# Encode categorical variables
label_encoders = {}
cat_cols = ['Supplier', 'Item_Category']

for col in cat_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

# Encode target
target_column = 'Compliance'
le_target = LabelEncoder()
df[target_column] = le_target.fit_transform(df[target_column])
label_encoders['Compliance'] = le_target

X = df.drop(columns=[target_column])
y = df[target_column]

print(f"✓ Features: {X.shape}")
print(f"✓ Class distribution: {Counter(y)}")

# Scale features
print("\n[3/6] Scaling features...")
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_scaled_df = pd.DataFrame(X_scaled, columns=X.columns)

# Cold-start feature engineering
print("\n[4/6] Adding cold-start features...")
X_scaled_df['Avg_Order_Quantity'] = X_scaled_df['Quantity'].mean()
X_scaled_df['Median_Delivery_Delay'] = X_scaled_df['Delivery_Delay'].median()
X_scaled_df['Price_Difference'] = X_scaled_df['Unit_Price'] - X_scaled_df['Negotiated_Price']
X_scaled_df['Delay_per_Quantity'] = X_scaled_df['Delivery_Delay'] / (X_scaled_df['Quantity'] + 1e-6)

# One-hot encode only Item_Category (Order_Status removed for cold-start)
cold_start_cat_cols = ['Item_Category']
X_scaled_df = pd.get_dummies(X_scaled_df, columns=cold_start_cat_cols, drop_first=True)
X_scaled_df = X_scaled_df.drop(columns=['Supplier'], errors='ignore')

print(f"✓ Final features: {X_scaled_df.shape}")

# Train-test split and SMOTE
print("\n[5/6] Training model...")
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled_df, y, test_size=0.2, random_state=42, stratify=y
)

smote = SMOTE(random_state=42)
X_train_res, y_train_res = smote.fit_resample(X_train, y_train)

# Train Random Forest
model = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
model.fit(X_train_res, y_train_res)

from sklearn.metrics import accuracy_score, roc_auc_score
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]
accuracy = accuracy_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_prob)

print(f"✓ Model trained!")
print(f"  Accuracy: {accuracy:.4f}")
print(f"  ROC-AUC: {roc_auc:.4f}")

# Save artifacts
print("\n[6/6] Saving model artifacts...")

with open('model.pkl', 'wb') as f:
    pickle.dump(model, f)
print("✓ Saved: model.pkl")

with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)
print("✓ Saved: scaler.pkl")

with open('feature_columns.pkl', 'wb') as f:
    pickle.dump(X_scaled_df.columns.tolist(), f)
print("✓ Saved: feature_columns.pkl")

with open('label_encoders.pkl', 'wb') as f:
    pickle.dump(label_encoders, f)
print("✓ Saved: label_encoders.pkl")

print("\n" + "="*70)
print("✅ SUCCESS! All model files generated.")
print("="*70)
print("\nYou can now run: streamlit run app.py")
