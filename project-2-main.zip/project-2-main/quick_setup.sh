#!/bin/bash

echo "========================================="
echo "Supplier Selection App - Quick Setup"
echo "========================================="
echo ""

echo "[1/4] Creating virtual environment..."
python3 -m venv venv
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to create virtual environment"
    echo "Make sure Python 3 is installed"
    exit 1
fi
echo "    Done!"
echo ""

echo "[2/4] Activating virtual environment..."
source venv/bin/activate
echo "    Done!"
echo ""

echo "[3/4] Installing dependencies..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    exit 1
fi
echo "    Done!"
echo ""

echo "[4/4] Starting Streamlit app..."
echo ""
echo "========================================="
echo "Setup Complete! Starting app..."
echo "Open browser to: http://localhost:8501"
echo "Press Ctrl+C to stop the app"
echo "========================================="
echo ""

streamlit run app.py
