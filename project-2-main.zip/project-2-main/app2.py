import streamlit as st
import pandas as pd
import numpy as np
import pickle
from datetime import datetime
import plotly.express as px

# Page configuration
st.set_page_config(page_title="Supplier Selection System", page_icon="📦", layout="wide")

# Load model and preprocessing artifacts
@st.cache_resource
def load_artifacts():
    try:
        with open('model.pkl', 'rb') as f:
            model = pickle.load(f)
        with open('scaler.pkl', 'rb') as f:
            scaler = pickle.load(f)
        with open('feature_columns.pkl', 'rb') as f:
            feature_columns = pickle.load(f)
        return model, scaler, feature_columns
    except Exception as e:
        st.error(f"Error loading model artifacts: {e}")
        return None, None, None

model, scaler, feature_columns = load_artifacts()

# Sidebar
with st.sidebar:
    st.header("⚙️ Input Configuration")
    mode = st.radio("Select Mode", ["Single Prediction", "Batch Prediction", "Model Performance"])

# ---------------- SINGLE PREDICTION ----------------
if mode == "Single Prediction":
    st.title("🔍 Single Supplier Evaluation")

    col1, col2 = st.columns(2)
    with col1:
        supplier_id = st.text_input("Supplier ID", value="SUP001")
        quantity = st.number_input("Quantity", min_value=1, value=100)
        unit_price = st.number_input("Unit Price ($)", min_value=0.01, value=50.0)
        negotiated_price = st.number_input("Negotiated Price ($)", min_value=0.01, value=45.0)
        item_category = st.selectbox("Item Category", ["Electronics", "Raw Materials", "Packaging", "Office Supplies", "Components", "Other"])
    with col2:
        order_date = st.date_input("Order Date", value=datetime(2023, 1, 1))
        delivery_date = st.date_input("Delivery Date", value=datetime(2023, 1, 10))

    if st.button("🚀 Predict"):
        if model is not None:
            try:
                order_date_dt = pd.to_datetime(order_date)
                delivery_date_dt = pd.to_datetime(delivery_date)
                category_map = {
                    "Electronics": 0,
                    "Raw Materials": 4,
                    "Packaging": 3,
                    "Office Supplies": 2,
                    "Components": 1,
                    "Other": 1
                }
                input_data = {
                    'Quantity': quantity,
                    'Unit_Price': unit_price,
                    'Negotiated_Price': negotiated_price,
                    'Order_Year': order_date_dt.year,
                    'Order_Month': order_date_dt.month,
                    'Order_Day': order_date_dt.day,
                    'Delivery_Year': delivery_date_dt.year,
                    'Delivery_Month': delivery_date_dt.month,
                    'Delivery_Day': delivery_date_dt.day,
                    'Delivery_Delay': (delivery_date_dt - order_date_dt).days,
                    'Avg_Order_Quantity': quantity,
                    'Median_Delivery_Delay': (delivery_date_dt - order_date_dt).days,
                    'Price_Difference': unit_price - negotiated_price,
                    'Delay_per_Quantity': (delivery_date_dt - order_date_dt).days / (quantity + 1e-6),
                    'Item_Category': category_map.get(item_category, 1)
                }
                input_df = pd.DataFrame([input_data])
                for col in feature_columns:
                    if col not in input_df.columns:
                        input_df[col] = 0
                input_df = input_df[feature_columns]
                prediction = model.predict(input_df)[0]
                probability = model.predict_proba(input_df)[0]
                approved_prob = probability[1]  # Probability of Approved class
                if approved_prob >= 0.8:
                    status = "✅ Approved"
                else:
                    status = "⚠️ Flagged"
                confidence_score = f"{max(probability) * 100:.2f}%"
                risk_level = "Low" if max(probability) > 0.8 else "Medium" if max(probability) > 0.6 else "High"

                st.subheader("📊 Prediction Result")
                st.write(f"**Supplier ID:** {supplier_id}")
                st.write(f"**Status:** {status}")
                st.write(f"**Confidence Score:** {confidence_score}")
                st.write(f"**Risk Level:** {risk_level}")
            except Exception as e:
                st.error(f"Prediction error: {e}")
        else:
            st.error("Model not loaded.")

# ---------------- BATCH PREDICTION ----------------
elif mode == "Batch Prediction":
    st.title("📦 Batch Supplier Evaluation")
    uploaded_file = st.file_uploader("Upload CSV File", type=["csv"])
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            st.write("### Uploaded Data Preview")
            st.dataframe(df.head())

            if st.button("🚀 Process Batch"):
                results = []
                category_map = {
                    "Electronics": 0,
                    "Raw Materials": 4,
                    "Packaging": 3,
                    "Office Supplies": 2,
                    "Components": 1,
                    "Other": 1
                }

                for idx, row in df.iterrows():
                    try:
                        order_date_dt = pd.to_datetime(row['Order_Date'])
                        delivery_date_dt = pd.to_datetime(row['Delivery_Date'])
                        quantity = row['Quantity']
                        unit_price = row['Unit_Price']
                        negotiated_price = row['Negotiated_Price']
                        item_category = row['Item_Category']
                        supplier_id = row.get('Supplier_ID', f"SUP-{idx+1}")

                        input_data = {
                            'Quantity': quantity,
                            'Unit_Price': unit_price,
                            'Negotiated_Price': negotiated_price,
                            'Order_Year': order_date_dt.year,
                            'Order_Month': order_date_dt.month,
                            'Order_Day': order_date_dt.day,
                            'Delivery_Year': delivery_date_dt.year,
                            'Delivery_Month': delivery_date_dt.month,
                            'Delivery_Day': delivery_date_dt.day,
                            'Delivery_Delay': (delivery_date_dt - order_date_dt).days,
                            'Avg_Order_Quantity': quantity,
                            'Median_Delivery_Delay': (delivery_date_dt - order_date_dt).days,
                            'Price_Difference': unit_price - negotiated_price,
                            'Delay_per_Quantity': (delivery_date_dt - order_date_dt).days / (quantity + 1e-6),
                            'Item_Category': category_map.get(item_category, 1)
                        }

                        input_df = pd.DataFrame([input_data])
                        for col in feature_columns:
                            if col not in input_df.columns:
                                input_df[col] = 0
                        input_df = input_df[feature_columns]

                        prediction = model.predict(input_df)[0]
                        probability = model.predict_proba(input_df)[0]
                        status = "✅ Approved" if prediction == 1 else "⚠️ Flagged"
                        confidence_score = f"{max(probability) * 100:.2f}%"
                        risk_level = "Low" if max(probability) > 0.8 else "Medium" if max(probability) > 0.6 else "High"

                        results.append({
                            "Supplier_ID": supplier_id,
                            "Status": status,
                            "Confidence Score": confidence_score,
                            "Risk Level": risk_level
                        })
                    except Exception as e:
                        results.append({
                            "Supplier_ID": supplier_id,
                            "Status": "Error",
                            "Confidence Score": "N/A",
                            "Risk Level": str(e)
                        })

                results_df = pd.DataFrame(results)
                st.write("### 🧾 Batch Prediction Results")
                st.dataframe(results_df)

                approved_count = results_df["Status"].str.contains("Approved").sum()
                flagged_count = results_df["Status"].str.contains("Flagged").sum()

                col1, col2, col3 = st.columns(3)
                col1.metric("Total Suppliers", len(results_df))
                col2.metric("Predicted Approved", approved_count)
                col3.metric("Predicted Flagged", flagged_count)

                csv = results_df.to_csv(index=False).encode('utf-8')
                st.download_button("📥 Download Results CSV", data=csv, file_name="batch_results.csv", mime="text/csv")
        except Exception as e:
            st.error(f"Error processing file: {e}")

# ---------------- MODEL PERFORMANCE ----------------
else:
    st.title("📈 Model Performance")
    metrics_data = {
        'Model': ['Logistic Regression', 'Random Forest', 'Gradient Boosting', 'SVM', 'KNN', 'XGBoost'],
        'Accuracy': [0.7617, 0.9336, 0.8633, 0.8516, 0.7812, 0.9023],
        'ROC-AUC': [0.8576, 0.9744, 0.9372, 0.9137, 0.8817, 0.9579]
    }
    df_metrics = pd.DataFrame(metrics_data)

    col1, col2 = st.columns(2)
    with col1:
        fig = px.bar(df_metrics, x='Model', y='Accuracy', title='Model Accuracy Comparison', color='Accuracy', color_continuous_scale='Blues')
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        fig2 = px.bar(df_metrics, x='Model', y='ROC-AUC', title='ROC-AUC Score Comparison', color='ROC-AUC', color_continuous_scale='Greens')
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown("### 🏆 Best Model: Random Forest")
    st.info("""
    **Random Forest Classifier**
    - Accuracy: 93.36%
    - ROC-AUC: 0.9744
    - Precision: 0.9744
    - Recall: 0.8906
    - Trained on SMOTE-balanced data
    - Cold-start capable
    """)