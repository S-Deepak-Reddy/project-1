# 🚀 Deploy to Streamlit Cloud - Step by Step Guide

## ✅ Pre-requisites Check

All required files are ready:
- ✅ app.py
- ✅ requirements.txt
- ✅ model.pkl (4.8MB)
- ✅ scaler.pkl
- ✅ feature_columns.pkl
- ✅ label_encoders.pkl
- ✅ README.md
- ✅ .gitignore

**Total size: ~4.9MB** ✓ (Under GitHub's 100MB file limit)

---

## 📋 Step-by-Step Deployment

### Step 1: Configure Git (First Time Only)

Open your terminal and run these commands:

```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

Replace with your actual name and email.

### Step 2: Commit Files to Git

```bash
# Already done: git add (files are staged)

# Commit the files
git commit -m "Initial commit: Supplier selection cold-start system"

# Check status
git status
```

### Step 3: Create GitHub Repository

**Option A: Using GitHub Website (Easier)**

1. Go to: https://github.com/new
2. Repository name: `supplier-selection-app`
3. Description: "ML-powered supplier selection and compliance prediction for cold-start suppliers"
4. Choose: **Public** (required for free Streamlit Cloud)
5. DO NOT initialize with README (we already have one)
6. Click "Create repository"

**Option B: Using GitHub Desktop**

1. Download GitHub Desktop: https://desktop.github.com/
2. Open GitHub Desktop
3. File → Add Local Repository
4. Browse to: `C:\Users\Admin\deepak`
5. Click "Publish repository"
6. Name: `supplier-selection-app`
7. Make sure "Keep this code private" is **UNCHECKED**
8. Click "Publish repository"

### Step 4: Push to GitHub (If using terminal)

After creating the repository on GitHub, copy the commands shown and run:

```bash
# Set the branch to main
git branch -M main

# Add GitHub as remote (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/supplier-selection-app.git

# Push to GitHub
git push -u origin main
```

**Example:**
```bash
git branch -M main
git remote add origin https://github.com/johndoe/supplier-selection-app.git
git push -u origin main
```

You may be asked to authenticate with GitHub. Follow the prompts.

### Step 5: Deploy to Streamlit Cloud

1. **Go to Streamlit Cloud:**
   - Visit: https://share.streamlit.io/
   - Click "Sign in" (use your GitHub account)

2. **Deploy New App:**
   - Click "New app" button (top right)
   - Or go to: https://share.streamlit.io/deploy

3. **Configure Deployment:**
   - **Repository:** Select `YOUR_USERNAME/supplier-selection-app`
   - **Branch:** `main`
   - **Main file path:** `app.py`
   - Click "Deploy!"

4. **Wait for Deployment:**
   - Streamlit will install dependencies from requirements.txt
   - This takes 2-5 minutes
   - Watch the logs for any errors

5. **Your App is Live!**
   - You'll get a URL like: `https://YOUR_USERNAME-supplier-selection-app.streamlit.app`
   - Share this URL with anyone!

---

## 🎯 Quick Commands Summary

```bash
# Configure Git (first time only)
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# Commit files
git commit -m "Initial commit: Supplier selection cold-start system"

# Push to GitHub
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/supplier-selection-app.git
git push -u origin main
```

Then deploy on: https://share.streamlit.io/

---

## ⚠️ Common Issues & Solutions

### Issue: "fatal: unable to auto-detect email address"
**Solution:** Run the git config commands in Step 1

### Issue: "remote: Repository not found"
**Solution:**
- Check you created the repository on GitHub
- Make sure the URL is correct
- Verify you're logged into GitHub

### Issue: "Permission denied (publickey)"
**Solution:**
- Use HTTPS URL instead of SSH
- Or set up SSH keys: https://docs.github.com/en/authentication

### Issue: "File too large" on GitHub
**Solution:**
- Model.pkl is 4.8MB, which is fine
- If issues persist, use Git LFS: https://git-lfs.github.com/

### Issue: Streamlit deployment fails
**Solution:**
- Check the deployment logs
- Verify all .pkl files are in the repository
- Make sure requirements.txt has all dependencies

### Issue: "Model not loaded" error on Streamlit Cloud
**Solution:**
- Verify model.pkl, scaler.pkl, feature_columns.pkl, label_encoders.pkl are all pushed to GitHub
- Check file paths are correct (should be in root directory)

---

## 🔄 To Update Your Deployed App

After making changes to your code:

```bash
git add .
git commit -m "Description of changes"
git push

# Streamlit Cloud will auto-deploy the changes!
```

---

## 📊 After Deployment

Your app will be available at:
`https://YOUR_USERNAME-supplier-selection-app.streamlit.app`

**Features Available:**
- ✅ Single supplier prediction
- ✅ Batch processing
- ✅ Model performance dashboard
- ✅ Cold-start ready for new suppliers

**Share with:**
- Your team
- Professors/reviewers
- Potential employers
- Anyone with the link!

---

## 💡 Pro Tips

1. **Custom Domain:** You can add a custom domain in Streamlit Cloud settings
2. **Analytics:** Enable analytics in Streamlit Cloud dashboard
3. **Secrets:** For sensitive data, use Streamlit secrets (not needed for this app)
4. **Resource Limits:** Free tier gives you 1GB RAM and 1 CPU core

---

## 🆘 Need Help?

- **Streamlit Docs:** https://docs.streamlit.io/streamlit-community-cloud/deploy-your-app
- **GitHub Help:** https://docs.github.com/en/get-started
- **Streamlit Community:** https://discuss.streamlit.io/

---

## ✅ Deployment Checklist

Before deploying, verify:
- [ ] Git configured with name and email
- [ ] Files committed to git
- [ ] GitHub repository created (public)
- [ ] Code pushed to GitHub
- [ ] Streamlit Cloud account created
- [ ] App deployed on Streamlit Cloud
- [ ] App URL works and displays correctly

---

**Your app is ready to go live!** 🚀

**Next Step:** Configure git and run the commands above!
