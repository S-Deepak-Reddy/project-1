# 💻 Setup Guide - Running Project on New Laptop

This guide will help you run the **Supplier Selection Cold-Start System** on any new laptop/machine.

---

## 📋 Prerequisites

### Required Software:
1. **Python 3.8 or higher** (3.11 recommended)
2. **Git** (optional, but recommended)
3. **Internet connection** (for installing packages)

---

## 🚀 Setup Steps

### Step 1: Install Python

**Windows:**
1. Go to: https://www.python.org/downloads/
2. Download Python 3.11 (or latest version)
3. Run installer
4. ✅ **IMPORTANT:** Check "Add Python to PATH"
5. Click "Install Now"

**Mac/Linux:**
```bash
# Mac (using Homebrew)
brew install python@3.11

# Ubuntu/Debian
sudo apt update
sudo apt install python3.11 python3-pip

# Verify installation
python --version
# or
python3 --version
```

### Step 2: Get the Project Files

**Option A: Download from GitHub (If deployed)**
```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/supplier-selection-app.git
cd supplier-selection-app
```

**Option B: Copy Files Manually**

Copy these files to a new folder on your laptop:
```
supplier-selection-app/
├── app.py
├── requirements.txt
├── model.pkl
├── scaler.pkl
├── feature_columns.pkl
├── label_encoders.pkl
├── README.md
└── Procurement KPI Analysis Dataset.csv (optional)
```

**Required Files (8):**
- ✅ `app.py` (11KB)
- ✅ `requirements.txt` (121 bytes)
- ✅ `model.pkl` (4.8MB)
- ✅ `scaler.pkl` (999 bytes)
- ✅ `feature_columns.pkl` (389 bytes)
- ✅ `label_encoders.pkl` (531 bytes)
- ✅ `README.md` (optional but recommended)
- ✅ `Procurement KPI Analysis Dataset.csv` (optional - only for retraining)

---

### Step 3: Open Terminal/Command Prompt

**Windows:**
- Press `Win + R`
- Type: `cmd` or `powershell`
- Press Enter

**Mac/Linux:**
- Press `Cmd + Space` (Mac) or `Ctrl + Alt + T` (Linux)
- Type: `terminal`
- Press Enter

Navigate to project folder:
```bash
cd path/to/supplier-selection-app
```

---

### Step 4: Create Virtual Environment (Recommended)

This keeps your project dependencies isolated:

```bash
# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate

# Mac/Linux:
source venv/bin/activate

# You should see (venv) in your terminal prompt
```

---

### Step 5: Install Required Packages

```bash
# Make sure you're in the project directory
# Install all dependencies from requirements.txt
pip install -r requirements.txt
```

This will install:
- streamlit
- pandas
- numpy
- scikit-learn
- imbalanced-learn
- plotly

**Wait for installation to complete** (takes 1-3 minutes)

---

### Step 6: Verify Installation

```bash
# Check if packages are installed
pip list

# You should see:
# streamlit, pandas, numpy, scikit-learn, imbalanced-learn, plotly
```

---

### Step 7: Run the App

```bash
# Start the Streamlit app
streamlit run app.py
```

**Expected Output:**
```
  You can now view your Streamlit app in your browser.

  Local URL: http://localhost:8501
  Network URL: http://192.168.x.x:8501
```

---

### Step 8: Access the App

1. Your browser should open automatically
2. If not, manually open: **http://localhost:8501**
3. You should see the Supplier Selection System interface!

---

## ✅ Verification Checklist

After setup, verify everything works:

- [ ] Python installed (check: `python --version`)
- [ ] All 8 files present in project folder
- [ ] Virtual environment created and activated
- [ ] Dependencies installed successfully
- [ ] App runs without errors (`streamlit run app.py`)
- [ ] Browser opens to http://localhost:8501
- [ ] App interface loads correctly
- [ ] Can enter data in the form
- [ ] "Predict Compliance" button works
- [ ] Results display correctly

---

## 🔧 Troubleshooting

### Issue: "Python is not recognized"
**Solution:**
- Reinstall Python with "Add to PATH" checked
- Or manually add Python to system PATH
- Windows: Search "Environment Variables" → Edit PATH → Add Python folder

### Issue: "pip is not recognized"
**Solution:**
```bash
# Use python -m pip instead
python -m pip install -r requirements.txt
```

### Issue: "No module named 'streamlit'"
**Solution:**
```bash
# Make sure virtual environment is activated (you should see (venv))
# If not, activate it first, then:
pip install streamlit
```

### Issue: "Error loading model artifacts"
**Solution:**
- Verify all .pkl files are in the same directory as app.py
- Check file names match exactly:
  - model.pkl
  - scaler.pkl
  - feature_columns.pkl
  - label_encoders.pkl

### Issue: "Port 8501 is already in use"
**Solution:**
```bash
# Stop the existing app (Ctrl+C)
# Or use a different port:
streamlit run app.py --server.port 8502
```

### Issue: "ModuleNotFoundError: No module named 'sklearn'"
**Solution:**
```bash
pip install scikit-learn
```

### Issue: App is very slow
**Solution:**
- Close other applications
- Model files (4.8MB) need to load once
- After first load, it's cached and will be faster

---

## 🖥️ System Requirements

**Minimum:**
- RAM: 2GB
- Storage: 100MB free space
- Internet: For installation only
- OS: Windows 7+, macOS 10.13+, or Linux

**Recommended:**
- RAM: 4GB+
- Storage: 500MB free space
- Internet: For installation
- OS: Windows 10+, macOS 11+, or modern Linux

---

## 📦 Package Versions (from requirements.txt)

```
streamlit==1.31.0
pandas==2.2.0
numpy==1.26.4
scikit-learn==1.4.0
imbalanced-learn==0.12.0
plotly==5.18.0
```

If you have issues with specific versions, you can install latest versions:
```bash
pip install streamlit pandas numpy scikit-learn imbalanced-learn plotly
```

---

## 🔄 Updating the App

If you make changes to the code:

1. **Save your changes** in `app.py`
2. **Refresh browser** - Streamlit auto-detects changes
3. Click "Rerun" in the top-right corner

Or just refresh the page (Ctrl+R / Cmd+R)

---

## 🛑 Stopping the App

In the terminal where the app is running:
- Press **Ctrl + C**
- Type `y` if prompted
- The app will stop

---

## 📤 Sharing the App on Local Network

To allow others on your network to access:

1. Run the app normally:
   ```bash
   streamlit run app.py
   ```

2. Note the **Network URL** from the output:
   ```
   Network URL: http://192.168.x.x:8501
   ```

3. Share this URL with others on the same WiFi/network

4. They can access it from their devices!

---

## 🆕 First Time Setup - Quick Command List

```bash
# 1. Navigate to project folder
cd path/to/supplier-selection-app

# 2. Create virtual environment
python -m venv venv

# 3. Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Run the app
streamlit run app.py

# 6. Open browser to http://localhost:8501
```

Copy these commands one by one!

---

## 🔁 Running App Again (After First Setup)

Next time you want to run the app:

```bash
# 1. Navigate to project folder
cd path/to/supplier-selection-app

# 2. Activate virtual environment (if used)
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 3. Run the app
streamlit run app.py

# That's it!
```

---

## 💾 Backup Important Files

Always keep backups of:
- ✅ `model.pkl` (4.8MB) - The trained model
- ✅ `scaler.pkl`
- ✅ `feature_columns.pkl`
- ✅ `label_encoders.pkl`
- ✅ `app.py`
- ✅ `requirements.txt`

If you lose these files, you'll need to retrain the model using `generate_model.py` and the dataset.

---

## 🎓 For Presentation/Demo

**Before Presentation:**
1. Test the app day before
2. Have sample data ready
3. Close unnecessary applications
4. Test on the demo laptop
5. Have backup plan (screenshots/video)

**During Presentation:**
1. Start app 5 minutes early
2. Open to http://localhost:8501
3. Test a quick prediction
4. Have example inputs ready
5. Know your accuracy metrics (76.28% accuracy)

---

## 📞 Getting Help

**If you encounter issues:**

1. **Check logs** in terminal for error messages
2. **Verify files** - all .pkl files present?
3. **Check Python version** - 3.8+ required
4. **Reinstall packages** - `pip install -r requirements.txt --force-reinstall`
5. **Try without virtual environment** - Some systems don't need it

**Common Questions:**

Q: Do I need internet to run the app?
A: Only for initial installation. After that, it works offline.

Q: Can I run on multiple laptops simultaneously?
A: Yes! Just follow this guide on each laptop.

Q: How long does setup take?
A: 5-10 minutes (including package installation)

Q: Can I use Python 3.7?
A: Recommended 3.8+, but 3.7 might work. Best to use 3.11.

---

## ✨ Success!

If you see the Streamlit app in your browser with the supplier selection interface, **you're all set!** 🎉

Your app is now running locally and ready to predict supplier compliance!

---

## 📋 Quick Reference Card

**Start App:**
```bash
cd supplier-selection-app
venv\Scripts\activate  # Windows
streamlit run app.py
```

**Stop App:**
Press `Ctrl + C` in terminal

**Access App:**
http://localhost:8501

**Reinstall Packages:**
```bash
pip install -r requirements.txt --force-reinstall
```

---

**Setup Time:** ~10 minutes
**App Status:** Ready to use
**Support:** Check README.md for more details
