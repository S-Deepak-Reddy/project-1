# 📦 Transfer Project to New Laptop - Quick Guide

## 🎯 3 Ways to Transfer

### Option 1: Using GitHub (Recommended - Easiest)

**Once you deploy to GitHub:**

On the new laptop:
```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/supplier-selection-app.git
cd supplier-selection-app

# Run setup script
# Windows: double-click quick_setup.bat
# Mac/Linux: bash quick_setup.sh
```

**That's it!** The app will install and run automatically.

---

### Option 2: Using USB Drive/Cloud Storage

**Steps:**

1. **Copy entire project folder** to USB/Cloud:
   - Copy the folder: `C:\Users\Admin\deepak`
   - Paste to USB drive or upload to Google Drive/Dropbox

2. **On new laptop:**
   - Copy folder from USB/Cloud to new location
   - Open folder in terminal
   - Run setup script:
     - Windows: double-click `quick_setup.bat`
     - Mac/Linux: `bash quick_setup.sh`

---

### Option 3: Manual ZIP Transfer

**On current laptop:**
1. Right-click project folder → Send to → Compressed folder
2. Transfer the ZIP file via email/USB/cloud
3. Extract on new laptop
4. Run setup script or follow manual steps

---

## 📁 Required Files (Must Transfer All)

**Essential (6 files):**
- ✅ `app.py` - Main application
- ✅ `requirements.txt` - Dependencies list
- ✅ `model.pkl` - Trained model (4.8MB) **CRITICAL**
- ✅ `scaler.pkl` - Feature scaler **CRITICAL**
- ✅ `feature_columns.pkl` - Feature names **CRITICAL**
- ✅ `label_encoders.pkl` - Encoders **CRITICAL**

**Helpful:**
- ✅ `README.md` - Documentation
- ✅ `SETUP_NEW_MACHINE.md` - Setup instructions
- ✅ `quick_setup.bat` / `quick_setup.sh` - Automated setup

**Optional:**
- `Procurement KPI Analysis Dataset.csv` - Only if retraining
- `generate_model.py` - Only if retraining

---

## ⚡ Quick Setup on New Laptop

### Windows:
1. Copy all files to new laptop
2. Double-click `quick_setup.bat`
3. Wait for installation
4. Browser opens automatically to http://localhost:8501

### Mac/Linux:
1. Copy all files to new laptop
2. Open terminal in project folder
3. Make script executable: `chmod +x quick_setup.sh`
4. Run: `./quick_setup.sh`
5. Open browser to http://localhost:8501

---

## 🔧 Manual Setup (If Scripts Don't Work)

```bash
# 1. Navigate to project folder
cd path/to/supplier-selection-app

# 2. Create virtual environment
python -m venv venv

# 3. Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 4. Install packages
pip install -r requirements.txt

# 5. Run app
streamlit run app.py
```

---

## ✅ Verification

After setup, check:
- [ ] All .pkl files present (4 files)
- [ ] Python installed (run: `python --version`)
- [ ] App starts without errors
- [ ] Browser opens to http://localhost:8501
- [ ] Can enter data and get predictions

---

## 📊 Project Size

**Total size:** ~5MB
- model.pkl: 4.8MB (largest file)
- Other files: ~200KB

**Transfer time:**
- USB: < 1 second
- Email: < 10 seconds
- Cloud: < 30 seconds

---

## 🚀 Running on Multiple Laptops

You can run this app on unlimited laptops!

**For each new laptop:**
1. Copy files
2. Run `quick_setup.bat` (Windows) or `quick_setup.sh` (Mac/Linux)
3. Done!

**After first setup:**
- Just double-click `run_app.bat` (Windows)
- Or run `./run_app.sh` (Mac/Linux)

---

## 🎓 For Presentations/Demos

**Recommended approach:**

1. **Test on demo laptop** 1 day before
2. **Keep backup** on USB drive
3. **Have screenshots** as backup
4. **Know your metrics:** 76.28% accuracy
5. **Test internet** not required (runs offline)

**Demo day checklist:**
- [ ] Laptop charged
- [ ] Project copied and tested
- [ ] App runs successfully
- [ ] Sample data ready
- [ ] Know your talking points

---

## 💡 Pro Tips

1. **Always keep .pkl files safe** - They're critical!
2. **USB drive backup** - Fast and reliable
3. **Test before presentation** - No surprises
4. **Close other apps** - Better performance
5. **Screenshots ready** - Backup plan

---

## ⚠️ Common Issues & Solutions

### "Model not loaded"
→ Missing .pkl files. Copy all 4 .pkl files.

### "Python not found"
→ Install Python 3.8+ from python.org

### "Port already in use"
→ Close other instances or use: `streamlit run app.py --server.port 8502`

### App is slow
→ First load takes time. After that, it's fast (cached).

---

## 📞 Emergency Setup (No Internet)

If new laptop has no internet:

1. **On current laptop (with internet):**
   - Create virtual environment
   - Install all packages
   - Copy entire `venv` folder

2. **Transfer to new laptop:**
   - Copy project folder + venv folder
   - Activate venv
   - Run app

No internet needed on new laptop!

---

## 📋 File Transfer Checklist

Before transferring, verify you have:

**Critical Files (Don't miss these!):**
- [x] app.py
- [x] model.pkl (4.8MB)
- [x] scaler.pkl
- [x] feature_columns.pkl
- [x] label_encoders.pkl
- [x] requirements.txt

**Helper Files:**
- [x] quick_setup.bat / quick_setup.sh
- [x] run_app.bat / run_app.sh
- [x] SETUP_NEW_MACHINE.md
- [x] README.md

**Optional:**
- [ ] Dataset CSV
- [ ] generate_model.py

---

## 🎯 Summary

**Easiest Method:**
Use GitHub (once deployed)

**Fastest Method:**
USB drive with all files + quick_setup script

**Most Reliable:**
Copy all files manually + run setup commands

**Setup Time:**
- First time: 10 minutes
- Subsequent times: 30 seconds (just run app)

---

## ✨ Success Criteria

You'll know setup worked when:
1. ✅ Terminal shows "You can now view your Streamlit app"
2. ✅ Browser opens to http://localhost:8501
3. ✅ Interface loads with form fields
4. ✅ Can enter data and see predictions

---

**Your app is portable and ready to run anywhere!** 🚀

See `SETUP_NEW_MACHINE.md` for detailed instructions.
